import React, { useState, useEffect } from "react";
import { fetchUserById, updateUser } from "../api";
import { useParams, useNavigate } from "react-router-dom";
import "./EditUser.css";

const EditUser = () => {
    const { id } = useParams();
    const navigate = useNavigate();
    const [user, setUser] = useState({ first_name: "", last_name: "", avatar: "" });
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState(null);

    useEffect(() => {
        const loadUser = async () => {
            try {
                const fetchedUser = await fetchUserById(id);
                if (fetchedUser) {
                    setUser({ 
                        id: fetchedUser.id, // Make sure to include the id
                        first_name: fetchedUser.first_name, 
                        last_name: fetchedUser.last_name, 
                        avatar: fetchedUser.avatar 
                    });
                }
                setLoading(false);
            } catch (err) {
                setError("Failed to load user data");
                setLoading(false);
            }
        };
        loadUser();
    }, [id]);

    const handleUpdate = async (e) => {
        e.preventDefault();
        try {
            // Since the API doesn't actually update, we'll simulate the response
            const updatedUserData = {
                ...user,
                id: parseInt(id), // Ensure id is a number
                updatedAt: new Date().toISOString()
            };
            
            // Call the API (even though it won't persist)
            await updateUser(id, user);
            
            alert("User updated successfully!");
            // Pass the updated user data back to the UsersList
            navigate("/users", { state: { updatedUser: updatedUserData } });
        } catch (err) {
            setError("An error occurred while updating the user.");
        }
    };

    if (loading) return <p className="loading">Loading...</p>;
    if (error) return <p className="error">{error}</p>;

    return (
        <div className="edit-user-page">
            <div className="edit-user-container">
                {user.avatar && (
                    <div className="avatar-container">
                        <img src={user.avatar} alt="User Avatar" className="avatar" />
                    </div>
                )}
                <h2>Edit User</h2>
                <form className="edit-user-form" onSubmit={handleUpdate}>
                    <input
                        type="text"
                        placeholder="First Name"
                        value={user.first_name}
                        onChange={(e) => setUser({ ...user, first_name: e.target.value })}
                        required
                    />
                    <input
                        type="text"
                        placeholder="Last Name"
                        value={user.last_name}
                        onChange={(e) => setUser({ ...user, last_name: e.target.value })}
                        required
                    />
                    <input
                        type="text"
                        placeholder="Avatar URL"
                        value={user.avatar}
                        onChange={(e) => setUser({ ...user, avatar: e.target.value })}
                    />
                    <button type="submit">Save</button>
                </form>
            </div>
        </div>
    );
};

export default EditUser;