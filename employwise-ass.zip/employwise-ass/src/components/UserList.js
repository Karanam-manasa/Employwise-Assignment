import React, { useState, useEffect } from "react";
import { fetchUsers, deleteUser } from "../api";
import { useNavigate, useLocation } from "react-router-dom";
import "./UserList.css";

const UsersList = () => {
    const [users, setUsers] = useState([]);
    const [page, setPage] = useState(1);
    const navigate = useNavigate();
    const location = useLocation();

    useEffect(() => {
        const token = localStorage.getItem("token");
        if (!token) {
            navigate("/", { replace: true });
        }
    }, [navigate]);

    useEffect(() => {
        const getUsers = async () => {
            try {
                const data = await fetchUsers(page);
                if (data && data.data) {
                    // Check if we have a location state with updated user
                    if (location.state?.updatedUser) {
                        const updatedUsers = data.data.map(user => 
                            user.id === location.state.updatedUser.id ? 
                            location.state.updatedUser : user
                        );
                        setUsers(updatedUsers);
                    } else {
                        setUsers(data.data);
                    }
                }
            } catch (error) {
                console.error("Error fetching users:", error);
            }
        };
        getUsers();
    }, [page, location.state]);

    const handleDelete = async (id) => {
        if (await deleteUser(id)) {
            setUsers((prevUsers) => prevUsers.filter((user) => user.id !== id));
        }
    };

    const handleLogout = () => {
        localStorage.removeItem("token");
        navigate("/", { replace: true });
    };

    return (
        <div className="container">
            <h2 className="title">Users List</h2>
            <button className="logout-btn" onClick={handleLogout}>Logout</button>
            
            <table className="user-table">
                <thead>
                    <tr>
                        <th>Avatar</th>
                        <th>Name</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    {users.map((user) => (
                        <tr key={user.id}>
                            <td><img src={user.avatar} alt="Avatar" className="avatar" /></td>
                            <td>{user.first_name} {user.last_name}</td>
                            <td className="action-column">
                                <button 
                                    className="edit-btn" 
                                    onClick={() => navigate(`/edit/${user.id}`)}
                                >
                                    Edit
                                </button>
                                <button className="delete-btn" onClick={() => handleDelete(user.id)}>Delete</button>
                            </td>
                        </tr>
                    ))}
                </tbody>
            </table>

            <div className="pagination">
                <button 
                    className="page-btn" 
                    onClick={() => setPage((prev) => Math.max(prev - 1, 1))} 
                    disabled={page === 1}
                >
                    Previous
                </button>
                <button className="page-btn" onClick={() => setPage(page + 1)}>Next</button>
            </div>
        </div>
    );
};

export default UsersList;