import axios from "axios";

const API_URL = "https://reqres.in/api/users";
const LOGIN_URL = "https://reqres.in/api/login"; // Separate login URL

// ✅ Fetch all users (For Users List)
export const fetchUsers = async (page = 1) => {
    try {
        const response = await axios.get(`${API_URL}?page=${page}`);
        return response.data; // Returns paginated user list
    } catch (error) {
        console.error("Error fetching users:", error);
        return { data: [] }; // Return empty array to prevent crash
    }
};

// ✅ Login User
export const loginUser = async (email, password) => {
    try {
        const response = await axios.post(LOGIN_URL, { email, password });
        return response.data.token; // Returns the authentication token
    } catch (error) {
        console.error("Login failed:", error.response?.data?.error || error.message);
        throw new Error("Invalid credentials");
    }
};

// ✅ Fetch a user by ID (For Edit Page)
export const fetchUserById = async (id) => {
    try {
        const response = await axios.get(`${API_URL}/${id}`);
        return response.data.data; // API response contains a "data" object
    } catch (error) {
        console.error("Error fetching user by ID:", error);
        return null; // Return null if user not found
    }
};

// ✅ Update a user (For Edit Page)
export const updateUser = async (id, updatedUserData) => {
    try {
        const response = await axios.put(`${API_URL}/${id}`, updatedUserData, {
            headers: { "Content-Type": "application/json" },
        });
        return response.data; // Returns updated user details
    } catch (error) {
        console.error("Error updating user:", error);
        return null;
    }
};

// ✅ Delete a user (For Delete Button in Users List)
export const deleteUser = async (id) => {
    try {
        const response = await axios.delete(`${API_URL}/${id}`);
        return response.status === 204; // Check if delete was successful
    } catch (error) {
        console.error("Error deleting user:", error);
        return false;
    }
};
